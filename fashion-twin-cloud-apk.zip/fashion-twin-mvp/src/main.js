import * as THREE from 'three';
import './style.css';

const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const STORE = { profile:'ft_profile_v2', face:'ft_face_v2', looks:'ft_saved_looks_v2', products:'ft_products_v2', settings:'ft_settings_v2' };
const defaultProfile = { name:'My Fashion Twin', height:181, weight:110, chest:109, waist:113, hips:112, shoulders:48, skin:'#9b684b', fit:'relaxed', size:'2XL' };
const profile = { ...defaultProfile, ...read(STORE.profile, {}) };
let faceData = read(STORE.face, '');
let looks = read(STORE.looks, []);
let products = read(STORE.products, []);
let settings = { aiEnabled:false, ...read(STORE.settings, {}) };
let currentColor = '#123f37', currentBottom = '#e8ddca', currentStyle = 'classic';
let currentProductId = null;
let scene, camera, renderer, avatar, garmentGroup, skinMaterial, kurtaMaterial, pantsMaterial;
let drag = null, zoom = 7.2, currentPage='studio';
const colors = [
  {name:'Emerald', hex:'#17483e', vibe:'Rich & festive'},
  {name:'Navy', hex:'#1c2d4b', vibe:'Slim & timeless'},
  {name:'Wine', hex:'#612e43', vibe:'Royal evening'},
  {name:'Rust', hex:'#884a32', vibe:'Warm & confident'},
  {name:'Ivory', hex:'#e4d5ba', vibe:'Classic celebration'},
  {name:'Black', hex:'#25282a', vibe:'Sharp & minimal'},
  {name:'Petrol', hex:'#1e5b61', vibe:'Modern statement'},
  {name:'Plum', hex:'#593c63', vibe:'Distinctive & rich'}
];
const styles = [
  {id:'classic',name:'Straight classic',desc:'Clean vertical line; easiest everyday festive pick.'},
  {id:'bandi',name:'Royal layered',desc:'A short open-front bandi look over a straight kurta.'},
  {id:'minimal',name:'Minimal festive',desc:'Low-detail collar and matte fabric for a neat silhouette.'}
];
const starterLooks = [
  {name:'Emerald Royal',color:'#17483e',bottom:'#e8ddca',style:'classic',tag:'Diwali favourite',detail:'Emerald kurta · ivory pyjama',search:'men emerald green straight kurta pajama 2XL'},
  {name:'Midnight Navy',color:'#1c2d4b',bottom:'#d9d6cf',style:'minimal',tag:'Slimming palette',detail:'Navy kurta · stone pyjama',search:'men navy blue kurta pajama set 2XL'},
  {name:'Wine Evening',color:'#612e43',bottom:'#e7ddce',style:'classic',tag:'Festive evening',detail:'Wine kurta · cream pyjama',search:'men wine maroon embroidered kurta pajama 2XL'},
  {name:'Petrol Modern',color:'#1e5b61',bottom:'#2f3436',style:'minimal',tag:'Modern royal',detail:'Petrol kurta · charcoal pyjama',search:'men petrol blue kurta pajama straight fit 2XL'},
  {name:'Rust Heritage',color:'#884a32',bottom:'#e8ddca',style:'bandi',tag:'Warm tones',detail:'Rust kurta · ivory pyjama',search:'men rust kurta pajama festive 2XL'},
  {name:'Black & Gold',color:'#25282a',bottom:'#d9c7a5',style:'classic',tag:'Sharp contrast',detail:'Black kurta · beige pyjama',search:'men black kurta pajama subtle gold 2XL'}
];

function read(key, fallback) { try { const value=localStorage.getItem(key); return value ? JSON.parse(value) : fallback; } catch { return fallback; } }
function write(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch { toast('Device storage is full. Remove a photo or saved look.'); return false; } }
function escapeHtml(s='') { return String(s).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function moneyFreeLabel() { return 'No paid API · No subscription · Local storage'; }

const app = $('#app');
app.innerHTML = `
  <header class="topbar">
    <button class="brand" data-page="studio" aria-label="Fashion Twin home"><span class="brand-icon">FT</span><span class="brand-copy"><strong>Fashion Twin</strong><small>Your style, your shape.</small></span></button>
    <div class="top-actions"><span class="privacy-pill"><i></i> Private by default</span><button id="settingsOpen" class="round-btn" aria-label="Settings">⚙</button></div>
  </header>
  <nav class="bottom-nav" aria-label="Main navigation">
    <button class="nav-item active" data-page="studio"><span>◉</span><small>Studio</small></button>
    <button class="nav-item" data-page="discover"><span>⌕</span><small>Discover</small></button>
    <button class="nav-item" data-page="twin"><span>♙</span><small>My Twin</small></button>
    <button class="nav-item" data-page="saved"><span>♡</span><small>Saved</small><b id="savedCount" class="nav-count hidden">0</b></button>
  </nav>
  <main>
    <section class="page active" id="page-studio">
      <div class="welcome-row"><div><p class="eyebrow">YOUR PERSONAL FITTING ROOM</p><h1>Find a look that<br><em>feels like you.</em></h1><p class="subhead">Explore flattering colours, preview outfits on your reusable 3D twin, and save the looks you love.</p></div><div class="avatar-chip" id="miniAvatar">FT</div></div>
      <section class="studio-layout">
        <article class="card preview-card">
          <div class="card-top"><div><span class="eyebrow">LIVE 3D PREVIEW</span><h2 id="previewTitle">Emerald Royal</h2></div><button id="resetView" class="round-btn" aria-label="Reset avatar view">↻</button></div>
          <div class="canvas-wrap" id="stage"><div class="loading-note">Preparing your 3D studio…</div><div class="canvas-badge">3D TWIN · PROTOTYPE</div></div>
          <div class="preview-controls"><span>↔ Drag to rotate</span><span>⌕ Pinch / scroll to zoom</span><button id="frontView">Front view</button></div>
          <div class="outfit-summary"><div class="color-dot" id="selectedDot"></div><div><strong id="outfitName">Emerald kurta + ivory pyjama</strong><small id="outfitDesc">Rich & festive · straight classic cut</small></div><button class="heart-btn" id="saveCurrent" aria-label="Save current look">♡</button></div>
          <div class="color-section"><div class="line-head"><strong>Choose your colour</strong><span>Matte shades photograph well</span></div><div class="swatch-list" id="swatches"></div></div>
          <div class="option-row"><label>Bottom wear<select id="bottomColor"><option value="#e8ddca">Ivory pyjama</option><option value="#d9d6cf">Stone pyjama</option><option value="#2f3436">Charcoal pyjama</option><option value="#c7ad84">Beige pyjama</option><option value="#25282a">Black pyjama</option></select></label><label>Kurta style<select id="kurtaStyle"><option value="classic">Straight classic</option><option value="minimal">Minimal festive</option><option value="bandi">Royal layered</option></select></label></div>
          <p class="disclaimer">This preview is a measurement-driven 3D prototype, not a real body scan or a guarantee of garment fit.</p>
        </article>
        <aside class="side-stack">
          <article class="card profile-card"><div class="card-top"><div><span class="eyebrow">YOUR PROFILE</span><h2>Fit that respects your shape</h2></div><span class="profile-symbol">♙</span></div><div class="profile-metrics"><div><small>Height</small><strong id="metricHeight">181 cm</strong></div><div><small>Weight</small><strong id="metricWeight">110 kg</strong></div><div><small>Usual size</small><strong id="metricSize">2XL</strong></div></div><div class="fit-note"><span class="fit-icon">✦</span><div><strong id="fitHeadline">Your fit preference: relaxed</strong><p id="fitBody">Prioritise room through the waist, clean shoulder seams and straight silhouettes.</p></div></div><button class="secondary full" data-page="twin">Edit body profile <span>→</span></button></article>
          <article class="card quick-card"><div class="quick-icon">✧</div><div><span class="eyebrow">STYLE STARTER</span><h3>Royal Diwali edit</h3><p>Deep jewel tones, restrained embroidery and straight-cut kurtas.</p><button class="text-link" data-page="discover">Explore outfit ideas <span>→</span></button></div></article>
          <article class="card zero-card"><div class="zero-icon">⌁</div><div><strong>Free to use daily</strong><p>3D viewer and saved looks run on your device. No AI API needed for these features.</p></div></article>
        </aside>
      </section>
      <section class="section-block"><div class="section-heading"><div><p class="eyebrow">PICK A DIRECTION</p><h2>Looks for your next occasion</h2></div><button class="text-link" data-page="discover">See all <span>→</span></button></div><div class="look-strip" id="homeLooks"></div></section>
    </section>

    <section class="page" id="page-discover">
      <div class="page-heading"><p class="eyebrow">DISCOVER YOUR NEXT LOOK</p><h1>Shop by <em>vibe.</em></h1><p class="subhead">Choose a curated look, preview its palette on your twin, then search Indian stores for real products in your size.</p></div>
      <div class="filter-bar"><div class="search-box"><span>⌕</span><input id="lookSearch" type="search" placeholder="Search colours, styles, occasions…"></div><select id="vibeFilter"><option value="all">All styles</option><option value="slimming">Visually streamlined</option><option value="royal">Royal & festive</option><option value="warm">Warm colours</option></select></div>
      <div class="fit-guidance"><span>✦</span><div><strong>Fit-first shopping tip</strong><p>Use the chart on each product page. A roomy chest and waist, correct shoulder seam and straight cut matter more than the size label alone.</p></div></div>
      <div class="catalog-grid" id="catalogGrid"></div>
      <section class="card upload-product-card"><div class="upload-art">＋</div><div class="upload-copy"><p class="eyebrow">FOUND SOMETHING ONLINE?</p><h2>Try your own product photo</h2><p>Upload a screenshot or product image from Myntra, Ajio, Amazon or any shop. It will be saved privately on this device so you can keep notes and open the original listing.</p><label class="primary inline-button" for="productUpload">Upload product image<input id="productUpload" type="file" accept="image/*" hidden></label></div></section>
      <div class="product-form hidden" id="productForm"><h3>Save product to your fitting room</h3><div class="product-form-grid"><label>Product name<input id="productName" placeholder="e.g. Emerald embroidered kurta"></label><label>Product / shop link<input id="productUrl" type="url" placeholder="https://…"></label><label>Listed size<input id="productSize" placeholder="e.g. XXL / 2XL"></label><label>Price (optional)<input id="productPrice" placeholder="₹1,499"></label></div><div class="form-actions"><button class="secondary" id="cancelProduct">Cancel</button><button class="primary" id="saveProduct">Save product</button></div></div>
      <section class="section-block"><div class="section-heading"><div><p class="eyebrow">SHOPPING SHORTCUTS</p><h2>Find real kurtas online</h2></div></div><div class="store-grid" id="storeLinks"></div><p class="tiny-note">These buttons open live store searches, not verified individual products. Check stock, return policy, measurements and final price before buying.</p></section>
    </section>

    <section class="page" id="page-twin">
      <div class="page-heading"><p class="eyebrow">YOUR REUSABLE MODEL</p><h1>Build your <em>twin.</em></h1><p class="subhead">Add real measurements and a face reference to personalise the local prototype. The photo is not uploaded to a server or reconstructed into a 3D face yet.</p></div>
      <div class="twin-layout"><section class="card"><div class="card-top"><div><span class="eyebrow">BODY PROFILE</span><h2>Your measurements</h2></div><span class="step-label">01 / 02</span></div><div class="form-grid"><label>Name / avatar label<input id="profileName" maxlength="40" value=""></label><label>Height (cm)<input id="height" type="number" min="130" max="230"></label><label>Weight (kg)<input id="weight" type="number" min="35" max="250"></label><label>Chest (cm)<input id="chest" type="number" min="50" max="180"></label><label>Waist (cm)<input id="waist" type="number" min="45" max="200"></label><label>Hips (cm)<input id="hips" type="number" min="50" max="190"></label><label>Shoulder width (cm)<input id="shoulders" type="number" min="30" max="90"></label><label>Usual top size<select id="size"><option>S</option><option>M</option><option>L</option><option>XL</option><option>2XL</option><option>3XL</option><option>4XL+</option><option>Not sure</option></select></label><label>Fit preference<select id="fit"><option value="relaxed">Relaxed — room to move</option><option value="regular">Regular — neat, not tight</option><option value="oversized">Oversized — loose silhouette</option></select></label></div><div class="skin-control"><div><strong>Skin tone reference</strong><p>Adjust the mannequin's approximate skin shade. This is a visual setting, not an inferred complexion.</p></div><div class="skin-swatches"><button data-skin="#f0c9a9" title="Light warm" style="background:#f0c9a9"></button><button data-skin="#d7a17e" title="Medium warm" style="background:#d7a17e"></button><button data-skin="#b77e5d" title="Medium deep" style="background:#b77e5d"></button><button data-skin="#9b684b" title="Deep warm" style="background:#9b684b"></button><button data-skin="#70462f" title="Deep" style="background:#70462f"></button></div></div><button id="applyMeasurements" class="primary full">Save profile & update twin</button><div class="success-note hidden" id="profileSaved">✓ Profile saved on this device.</div></section>
      <section class="card identity-card"><div class="card-top"><div><span class="eyebrow">IDENTITY REFERENCE</span><h2>Keep your face in mind</h2></div><span class="step-label">02 / 02</span></div><div class="face-large" id="faceLarge"><div class="face-placeholder">♙</div><p>No face reference yet</p></div><label class="upload-zone" for="facePhoto"><span class="upload-icon">＋</span><strong>Add face reference</strong><span>Clear front photo · JPG or PNG · up to 3 MB</span><input id="facePhoto" type="file" accept="image/*" hidden></label><div class="face-actions"><button id="removeFace" class="text-link danger">Remove photo</button><span class="local-lock">▣ Stored locally</span></div><div class="notice"><strong>Honest identity note</strong><p>The current 3D head is procedural. This image is a private reference only; it is not yet mapped to the avatar's face. A photo alone cannot guarantee an exact 3D reconstruction.</p></div></section></div>
      <section class="card body-help"><div class="help-icon">ⓘ</div><div><h3>How to get a better body match</h3><p>Measure over light clothing, keep the tape level, and use centimetres. Add front and side reference photos in even lighting when you are ready for a future calibrated reconstruction feature. Your height and tape measurements guide the current mannequin, but do not make it an exact scan.</p></div></section>
    </section>

    <section class="page" id="page-saved">
      <div class="page-heading"><p class="eyebrow">YOUR PRIVATE COLLECTION</p><h1>Looks worth <em>keeping.</em></h1><p class="subhead">Saved outfits and product screenshots stay in local device storage. Nothing syncs to an account.</p></div>
      <div class="saved-tabs"><button class="saved-tab active" data-saved-tab="looks">Saved looks <span id="savedLookTabCount">0</span></button><button class="saved-tab" data-saved-tab="products">Product shortlist <span id="savedProductTabCount">0</span></button></div>
      <div id="savedLooksGrid" class="catalog-grid"></div><div id="savedProductsGrid" class="product-list hidden"></div><div id="emptySaved" class="empty-state"><div>♡</div><h2>Your shortlist starts here</h2><p>Save a colour combination or upload a product you are considering. Compare options before you spend.</p><button class="primary" data-page="discover">Explore outfits</button></div>
    </section>
  </main>
  <footer class="app-footer"><span>FASHION TWIN · PRIVATE BY DESIGN</span><span>Local-first prototype · v0.2</span><button id="privacyOpen">Privacy & limits</button></footer>
  <div class="modal-backdrop hidden" id="modalBackdrop"><section class="modal-card" role="dialog" aria-modal="true" aria-labelledby="modalTitle"><div class="card-top"><h2 id="modalTitle">Settings</h2><button class="round-btn" id="modalClose" aria-label="Close">×</button></div><div id="modalBody"></div></section></div>
  <div id="toast" class="toast" role="status"></div>
`;

function toast(message) { const el=$('#toast'); el.textContent=message; el.classList.add('show'); clearTimeout(el._timer); el._timer=setTimeout(()=>el.classList.remove('show'),2600); }
function openModal(title, html) { $('#modalTitle').textContent=title; $('#modalBody').innerHTML=html; $('#modalBackdrop').classList.remove('hidden'); }
function closeModal() { $('#modalBackdrop').classList.add('hidden'); }
function hexToRgb(hex) { const n=parseInt(hex.replace('#',''),16); return {r:(n>>16)&255,g:(n>>8)&255,b:n&255}; }
function relativeLuminance(hex) { const {r,g,b}=hexToRgb(hex); return (0.2126*r+0.7152*g+0.0722*b)/255; }
function bmi() { return profile.weight / ((profile.height/100)**2); }
function styleName(id=currentStyle) { return styles.find(s=>s.id===id)?.name || 'Straight classic'; }
function colorName(hex) { return colors.find(c=>c.hex===hex)?.name || 'Custom'; }
function searchUrl(query, store='google') { const q=encodeURIComponent(query); if(store==='myntra') return `https://www.myntra.com/${q.replace(/%20/g,'-')}`; if(store==='ajio') return `https://www.ajio.com/search/?text=${q}`; if(store==='amazon') return `https://www.amazon.in/s?k=${q}`; if(store==='flipkart') return `https://www.flipkart.com/search?q=${q}`; return `https://www.google.com/search?tbm=shop&q=${q}`; }
function shopQuery(look) { return `${look.name||colorName(look.color)} men's straight kurta pajama ${profile.size} India`; }
function renderSwatches() { $('#swatches').innerHTML=colors.map(c=>`<button class="swatch ${currentColor===c.hex?'active':''}" data-color="${c.hex}" title="${c.name}" aria-label="${c.name}" style="--swatch:${c.hex}"><span>${currentColor===c.hex?'✓':''}</span></button>`).join(''); $$('.swatch',$('#swatches')).forEach(b=>b.addEventListener('click',()=>{currentColor=b.dataset.color;renderSwatches();updateAvatar();updateOutfitLabel();})); }
function updateOutfitLabel() { const bottom=$('#bottomColor')?.value||currentBottom; const style=$('#kurtaStyle')?.value||currentStyle; $('#previewTitle').textContent=`${colorName(currentColor)} ${style==='bandi'?'Royal Layer':style==='minimal'?'Minimal':'Classic'}`; $('#outfitName').textContent=`${colorName(currentColor)} kurta + ${bottomName(bottom)}`; $('#outfitDesc').textContent=`${colors.find(c=>c.hex===currentColor)?.vibe||'Your selected colour'} · ${styleName(style).toLowerCase()} cut`; $('#selectedDot').style.background=currentColor; }
function bottomName(hex) { return ({'#e8ddca':'ivory pyjama','#d9d6cf':'stone pyjama','#2f3436':'charcoal pyjama','#c7ad84':'beige pyjama','#25282a':'black pyjama'})[hex]||'pyjama'; }
function applyLook(look) { currentColor=look.color; currentBottom=look.bottom||'#e8ddca'; currentStyle=look.style||'classic'; $('#bottomColor').value=currentBottom; $('#kurtaStyle').value=currentStyle; renderSwatches(); updateAvatar(); updateOutfitLabel(); goPage('studio'); }
function lookCard(look, i=0) { return `<article class="look-card"><button class="look-visual" data-use-look="${escapeHtml(look.id||look.name)}" style="--look-color:${look.color};--bottom-color:${look.bottom||'#e8ddca'}"><span class="look-badge">${escapeHtml(look.tag||'Saved look')}</span><span class="mini-person"><i class="mini-head"></i><i class="mini-body"></i><i class="mini-leg left"></i><i class="mini-leg right"></i></span><span class="look-visual-label">${escapeHtml(colorName(look.color))}</span></button><div class="look-card-copy"><strong>${escapeHtml(look.name)}</strong><small>${escapeHtml(look.detail||`${colorName(look.color)} kurta · ${bottomName(look.bottom)}`)}</small><div class="look-card-actions"><button class="small-action" data-use-look="${escapeHtml(look.id||look.name)}">Try on</button><button class="small-action quiet" data-save-look="${escapeHtml(look.id||look.name)}">♡ Save</button></div></div></article>`; }
function renderHomeLooks() { $('#homeLooks').innerHTML=starterLooks.slice(0,4).map(lookCard).join(''); }
function renderCatalog() {
  const query=($('#lookSearch')?.value||'').toLowerCase(); const filter=$('#vibeFilter')?.value||'all';
  const items=starterLooks.filter(l=>`${l.name} ${l.detail} ${l.tag} ${l.search}`.toLowerCase().includes(query)).filter(l=>filter==='all'||(filter==='slimming'&&['#1c2d4b','#25282a','#1e5b61'].includes(l.color))||(filter==='royal'&&['#17483e','#612e43','#593c63'].includes(l.color))||(filter==='warm'&&['#884a32','#e4d5ba'].includes(l.color)));
  $('#catalogGrid').innerHTML=items.length?items.map(lookCard).join(''):`<div class="empty-inline">No looks match that search. Try another colour or style.</div>`;
  $('#storeLinks').innerHTML=[['Myntra','Find festive kurtas','myntra'],['AJIO','Explore ethnicwear','ajio'],['Amazon India','Compare prices & sizes','amazon'],['Flipkart','Browse kurta sets','flipkart'],['Google Shopping','Search across stores','google']].map(([name,desc,id])=>`<a class="store-card" href="${searchUrl('men straight kurta pajama '+profile.size+' under 2000',id)}" target="_blank" rel="noopener"><span class="store-mark">${name==='Myntra'?'M':name==='AJIO'?'A':name==='Amazon India'?'a':name==='Flipkart'?'F':'⌕'}</span><span><strong>${name}</strong><small>${desc}</small></span><b>↗</b></a>`).join('');
}
function renderSaved() {
  $('#savedCount').textContent=looks.length+products.length; $('#savedCount').classList.toggle('hidden',looks.length+products.length===0);
  $('#savedLookTabCount').textContent=looks.length; $('#savedProductTabCount').textContent=products.length;
  $('#savedLooksGrid').innerHTML=looks.map((l,i)=>`<article class="look-card"><button class="look-visual" data-use-saved="${i}" style="--look-color:${l.color};--bottom-color:${l.bottom||'#e8ddca'}"><span class="look-badge">Saved</span><span class="mini-person"><i class="mini-head"></i><i class="mini-body"></i><i class="mini-leg left"></i><i class="mini-leg right"></i></span><span class="look-visual-label">${escapeHtml(colorName(l.color))}</span></button><div class="look-card-copy"><strong>${escapeHtml(l.name)}</strong><small>${escapeHtml(l.detail||'Personal saved look')}</small><div class="look-card-actions"><button class="small-action" data-use-saved="${i}">Try on</button><button class="small-action quiet" data-delete-look="${i}">Remove</button></div></div></article>`).join('');
  $('#savedProductsGrid').innerHTML=products.map((p,i)=>`<article class="product-row"><div class="product-thumb">${p.image?`<img src="${p.image}" alt="${escapeHtml(p.name)}">`:'<span>▧</span>'}</div><div class="product-info"><strong>${escapeHtml(p.name)}</strong><small>${escapeHtml([p.price,p.size?`Size ${p.size}`:''].filter(Boolean).join(' · ')||'Product saved locally')}</small><div class="product-actions">${p.url?`<a class="small-action" href="${escapeHtml(p.url)}" target="_blank" rel="noopener">Open listing ↗</a>`:''}<button class="small-action quiet" data-product-preview="${i}">Preview palette</button><button class="small-action danger-action" data-delete-product="${i}">Remove</button></div></div></article>`).join('');
  const empty=looks.length===0&&products.length===0; $('#emptySaved').classList.toggle('hidden',!empty); $('#savedLooksGrid').classList.toggle('hidden',$('[data-saved-tab].active')?.dataset.savedTab==='products'); $('#savedProductsGrid').classList.toggle('hidden',$('[data-saved-tab].active')?.dataset.savedTab!=='products');
}
function saveCurrentLook() { const look={id:`look-${Date.now()}`,name:`${colorName(currentColor)} ${currentStyle==='bandi'?'Royal':currentStyle==='minimal'?'Minimal':'Classic'}`,color:currentColor,bottom:$('#bottomColor').value,style:$('#kurtaStyle').value,detail:`${colorName(currentColor)} kurta · ${bottomName($('#bottomColor').value)}`,created:Date.now()}; if(looks.some(l=>l.color===look.color&&l.bottom===look.bottom&&l.style===look.style)){toast('That exact look is already saved.');return;} looks.unshift(look); write(STORE.looks,looks); renderSaved(); toast('Look saved to your private collection.'); }
function fillProfileForm() { for(const key of ['height','weight','chest','waist','hips','shoulders','size','fit']) { const el=$('#'+key); if(el) el.value=profile[key]; } $('#profileName').value=profile.name; updateProfileSummary(); }
function updateProfileSummary() { $('#metricHeight').textContent=`${profile.height} cm`; $('#metricWeight').textContent=`${profile.weight} kg`; $('#metricSize').textContent=profile.size; $('#fitHeadline').textContent=`Your fit preference: ${profile.fit}`; $('#fitBody').textContent=profile.fit==='relaxed'?'Prioritise room through the waist, clean shoulder seams and straight silhouettes.':profile.fit==='regular'?'Choose enough ease to sit and move comfortably; never rely on the size label alone.':'Keep the oversized cut intentional with straight bottoms and a clean shoulder line.'; $('#miniAvatar').textContent=(profile.name||'FT').slice(0,2).toUpperCase(); }
function saveProfile() { const oldSkin=profile.skin; for(const key of ['height','weight','chest','waist','hips','shoulders']) profile[key]=Number($('#'+key).value)||defaultProfile[key]; profile.name=$('#profileName').value.trim()||'My Fashion Twin'; profile.size=$('#size').value; profile.fit=$('#fit').value; profile.skin=oldSkin; write(STORE.profile,profile); updateProfileSummary(); updateAvatar(); $('#profileSaved').classList.remove('hidden'); toast('Your measurements are saved on this device.'); }
function showFace(data) { faceData=data; if(data) write(STORE.face,data); else localStorage.removeItem(STORE.face); const box=$('#faceLarge'); box.innerHTML=data?`<img src="${data}" alt="Saved face reference"><div class="face-overlay"><span>PRIVATE REFERENCE</span></div>`:`<div class="face-placeholder">♙</div><p>No face reference yet</p>`; }
function compressImage(file, maxSide=1200, quality=.78) { return new Promise((resolve,reject)=>{ const reader=new FileReader(); reader.onerror=reject; reader.onload=()=>{ const img=new Image(); img.onerror=reject; img.onload=()=>{ const scale=Math.min(1,maxSide/Math.max(img.width,img.height)); const canvas=document.createElement('canvas'); canvas.width=Math.max(1,Math.round(img.width*scale)); canvas.height=Math.max(1,Math.round(img.height*scale)); const ctx=canvas.getContext('2d'); ctx.drawImage(img,0,0,canvas.width,canvas.height); resolve(canvas.toDataURL('image/jpeg',quality)); }; img.src=reader.result; }; reader.readAsDataURL(file); }); }
async function saveProductFromUpload(file) { if(!file)return; if(!file.type.startsWith('image/')){toast('Please choose an image file.');return;} if(file.size>10*1024*1024){toast('Please choose an image under 10 MB.');return;} try { const image=await compressImage(file,1000,.72); currentProductId=`product-${Date.now()}`; $('#productForm').classList.remove('hidden'); $('#productName').value=file.name.replace(/\.[^.]+$/,'').replace(/[-_]/g,' '); $('#productUrl').value=''; $('#productSize').value=profile.size; $('#productPrice').value=''; $('#productForm').dataset.image=image; $('#productForm').scrollIntoView({behavior:'smooth',block:'center'}); } catch { toast('Could not read that image. Please try another one.'); } }
function commitProduct() { const name=$('#productName').value.trim(); if(!name){toast('Add a name so you can find this product later.');return;} const url=$('#productUrl').value.trim(); if(url&&!/^https?:\/\//i.test(url)){toast('Enter a full link starting with https://');return;} products.unshift({id:currentProductId||`product-${Date.now()}`,name,url,size:$('#productSize').value.trim(),price:$('#productPrice').value.trim(),image:$('#productForm').dataset.image||'',created:Date.now()}); if(write(STORE.products,products)){ $('#productForm').classList.add('hidden'); $('#productUpload').value=''; renderSaved(); toast('Product saved locally.'); } }
function goPage(page) { currentPage=page; $$('.page').forEach(p=>p.classList.toggle('active',p.id===`page-${page}`)); $$('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.page===page)); if(page==='discover')renderCatalog(); if(page==='saved')renderSaved(); if(page==='twin')fillProfileForm(); window.scrollTo({top:0,behavior:'smooth'}); }
function setSavedTab(tab) { $$('.saved-tab').forEach(b=>b.classList.toggle('active',b.dataset.savedTab===tab)); renderSaved(); }

// 3D model: a consistent procedural mesh that is reshaped from the saved measurements.
function material(color, roughness=.8) { return new THREE.MeshStandardMaterial({color,roughness,metalness:0.01}); }
function addMesh(geometry, mat, pos, parent=avatar) { const mesh=new THREE.Mesh(geometry,mat); mesh.position.set(...pos); mesh.castShadow=true; mesh.receiveShadow=true; parent.add(mesh); return mesh; }
function taperedBody(topRadius,bottomRadius,height,mat,pos,scaleX=1,scaleZ=1) { const m=addMesh(new THREE.CylinderGeometry(topRadius,bottomRadius,height,48,12,false),mat,pos); m.scale.set(scaleX,1,scaleZ); return m; }
function buildAvatar() {
  if(!avatar)return; avatar.traverse(o=>{if(o.isMesh){o.geometry?.dispose(); if(Array.isArray(o.material))o.material.forEach(m=>m.dispose());else o.material?.dispose();}}); avatar.clear();
  const H=Math.max(150,Math.min(220,profile.height))/181; const chestRatio=Math.max(.82,Math.min(1.42,profile.chest/109)); const waistRatio=Math.max(.85,Math.min(1.5,profile.waist/100)); const hipRatio=Math.max(.85,Math.min(1.45,profile.hips/105)); const shoulderRatio=Math.max(.8,Math.min(1.28,profile.shoulders/48));
  const skin=material(profile.skin,.72), hair=material('#251d19',.92), dark=material('#25282b',.85), kurta=material(currentColor,.72), pyjama=material(currentBottom,.85), trim=material('#c7ad7d',.48);
  skinMaterial=skin; kurtaMaterial=kurta; pantsMaterial=pyjama;
  // Legs and shoes
  const legLen=1.12*H; const legX=.19*hipRatio;
  const legL=addMesh(new THREE.CapsuleGeometry(.135*hipRatio,Math.max(.2,legLen-.25),6,16),pyjama,[-legX,.69*H,0]); legL.scale.set(1,1,.94);
  const legR=addMesh(new THREE.CapsuleGeometry(.135*hipRatio,Math.max(.2,legLen-.25),6,16),pyjama,[legX,.69*H,0]); legR.scale.set(1,1,.94);
  addMesh(new THREE.BoxGeometry(.26,.13,.42),dark,[-legX,.09,.1]); addMesh(new THREE.BoxGeometry(.26,.13,.42),dark,[legX,.09,.1]);
  // Torso garment: overlapping smooth sections create a broader, natural silhouette rather than a tube.
  const torsoY=1.78*H; const torsoH=1.16*H;
  const torso=taperedBody(.43*chestRatio,.38*waistRatio,torsoH,kurta,[0,torsoY,0],shoulderRatio,1.02);
  torso.geometry.dispose();
  const torsoGeo=new THREE.CylinderGeometry(.40*chestRatio,.42*waistRatio,torsoH,48,18,false); const positions=torsoGeo.attributes.position;
  for(let i=0;i<positions.count;i++){const y=positions.getY(i); const t=(y+torsoH/2)/torsoH; const bulge=1+0.08*Math.sin(Math.PI*t); positions.setX(i,positions.getX(i)*bulge); positions.setZ(i,positions.getZ(i)*bulge);}
  torso.geometry=torsoGeo; torso.scale.set(shoulderRatio,1,1.03);
  // Neck and head
  addMesh(new THREE.CylinderGeometry(.105,.12,.22,24),skin,[0,2.42*H,0]);
  const head=addMesh(new THREE.SphereGeometry(.235,40,32),skin,[0,2.69*H,.015]); head.scale.set(1,1.16,.96);
  const hairCap=addMesh(new THREE.SphereGeometry(.24,32,24,0,Math.PI*2,0,Math.PI*.58),hair,[0,2.77*H,-.012]); hairCap.scale.set(1.02,1.02,1);
  // Ears, nose, eyebrows and eyes make the generic head more human-readable (not an identity reconstruction).
  addMesh(new THREE.SphereGeometry(.045,16,12),skin,[-.232,2.68*H,.005]); addMesh(new THREE.SphereGeometry(.045,16,12),skin,[.232,2.68*H,.005]);
  addMesh(new THREE.SphereGeometry(.035,16,12),skin,[0,2.665*H,.23]);
  const eyeMat=material('#30231d',.55); addMesh(new THREE.SphereGeometry(.018,12,10),eyeMat,[-.085,2.715*H,.212]); addMesh(new THREE.SphereGeometry(.018,12,10),eyeMat,[.085,2.715*H,.212]);
  const brow=material('#382720',.8); const browL=addMesh(new THREE.BoxGeometry(.07,.012,.012),brow,[-.085,2.75*H,.205]); browL.rotation.z=.06; const browR=addMesh(new THREE.BoxGeometry(.07,.012,.012),brow,[.085,2.75*H,.205]); browR.rotation.z=-.06;
  // Shoulder and sleeves
  const shoulderY=2.2*H; addMesh(new THREE.SphereGeometry(.22,24,18),kurta,[-.39*shoulderRatio,shoulderY,0]).scale.set(1.18,.78,.96); addMesh(new THREE.SphereGeometry(.22,24,18),kurta,[.39*shoulderRatio,shoulderY,0]).scale.set(1.18,.78,.96);
  const sleeveGeo=new THREE.CapsuleGeometry(.115,.52,5,20); const left=addMesh(sleeveGeo,kurta,[-.54*shoulderRatio,1.82*H,.01]); left.rotation.z=.06; left.scale.set(1,1,.94); const right=addMesh(sleeveGeo,kurta,[.54*shoulderRatio,1.82*H,.01]); right.rotation.z=-.06; right.scale.set(1,1,.94);
  addMesh(new THREE.SphereGeometry(.105,18,14),skin,[-.56*shoulderRatio,1.49*H,.01]); addMesh(new THREE.SphereGeometry(.105,18,14),skin,[.56*shoulderRatio,1.49*H,.01]);
  // Placket, collar, subtle buttons and hem seam
  addMesh(new THREE.BoxGeometry(.047,.40*H,.018),trim,[0,2.02*H,.405*chestRatio]);
  addMesh(new THREE.BoxGeometry(.22,.06,.08),kurta,[0,2.31*H,.02]);
  for(let i=0;i<3;i++)addMesh(new THREE.SphereGeometry(.012,10,8),trim,[0,(2.16-i*.095)*H,.42*chestRatio]);
  addMesh(new THREE.BoxGeometry(.74*waistRatio,.018,.012),trim,[0,1.21*H,.37*waistRatio]);
  if(currentStyle==='bandi') {
    const vestMat=material(new THREE.Color(currentColor).multiplyScalar(.78),.58);
    const vest=addMesh(new THREE.CylinderGeometry(.33*chestRatio,.36*waistRatio,.86*H,36,1,true),vestMat,[0,1.85*H,.09]); vest.scale.x=shoulderRatio;
    addMesh(new THREE.BoxGeometry(.018,.68*H,.015),trim,[-.17,1.86*H,.405*chestRatio]); addMesh(new THREE.BoxGeometry(.018,.68*H,.015),trim,[.17,1.86*H,.405*chestRatio]);
  }
  // Soft silhouette accents for a clear frontal garment view
  const hem=addMesh(new THREE.BoxGeometry(.66*waistRatio,.018,.014),trim,[0,1.19*H,.385*waistRatio]); hem.scale.x=waistRatio;
  avatar.scale.set(H,H,H);
}
function init3D() {
  const stage=$('#stage'); scene=new THREE.Scene(); scene.background=new THREE.Color('#eeeae3');
  camera=new THREE.PerspectiveCamera(31,stage.clientWidth/stage.clientHeight,.1,100); camera.position.set(0,2.05,zoom);
  renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,powerPreference:'low-power'}); renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.6)); renderer.setSize(stage.clientWidth,stage.clientHeight); renderer.shadowMap.enabled=true; renderer.shadowMap.type=THREE.PCFSoftShadowMap; renderer.outputColorSpace=THREE.SRGBColorSpace; renderer.toneMapping=THREE.ACESFilmicToneMapping; renderer.toneMappingExposure=1.08; stage.innerHTML=''; stage.appendChild(renderer.domElement);
  scene.add(new THREE.HemisphereLight(0xfff8ec,0x82776b,2.1)); const key=new THREE.DirectionalLight(0xffffff,2.4); key.position.set(-3,5,5); key.castShadow=true; scene.add(key); const fill=new THREE.DirectionalLight(0xd4e5e3,.7); fill.position.set(3,3,-3); scene.add(fill);
  const floor=new THREE.Mesh(new THREE.CircleGeometry(4,64),material('#e1d9ce',.96)); floor.rotation.x=-Math.PI/2; floor.position.y=-.025; floor.receiveShadow=true; scene.add(floor);
  const grid=new THREE.GridHelper(6,20,'#d6cec2','#e4ddd4'); grid.position.y=-.018; grid.material.opacity=.25; grid.material.transparent=true; scene.add(grid);
  avatar=new THREE.Group(); scene.add(avatar); buildAvatar();
  renderer.domElement.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY,rot:avatar.rotation.y,tilt:avatar.rotation.x};renderer.domElement.setPointerCapture?.(e.pointerId);});
  renderer.domElement.addEventListener('pointermove',e=>{if(!drag)return; avatar.rotation.y=drag.rot+(e.clientX-drag.x)*.009; avatar.rotation.x=Math.max(-.1,Math.min(.12,drag.tilt+(e.clientY-drag.y)*.002));});
  const endDrag=()=>drag=null; renderer.domElement.addEventListener('pointerup',endDrag);renderer.domElement.addEventListener('pointercancel',endDrag);
  renderer.domElement.addEventListener('wheel',e=>{zoom=Math.max(5.2,Math.min(9.8,zoom+e.deltaY*.006));camera.position.z=zoom;camera.lookAt(0,1.52,0);},{passive:true});
  $('#resetView').addEventListener('click',resetView); $('#frontView').addEventListener('click',resetView);
  window.addEventListener('resize',resize3D); camera.lookAt(0,1.52,0); animate();
}
function resetView() { if(!avatar||!camera)return; avatar.rotation.set(0,0,0);zoom=7.2;camera.position.set(0,2.05,zoom);camera.lookAt(0,1.52,0); }
function resize3D() { if(!renderer||!camera)return;const stage=$('#stage');if(!stage.clientWidth)return;camera.aspect=stage.clientWidth/stage.clientHeight;camera.updateProjectionMatrix();renderer.setSize(stage.clientWidth,stage.clientHeight); }
function animate() { requestAnimationFrame(animate); if(renderer&&scene&&camera)renderer.render(scene,camera); }
function updateAvatar() { if(!avatar)return; const rotY=avatar.rotation.y,rotX=avatar.rotation.x; buildAvatar(); avatar.rotation.y=rotY;avatar.rotation.x=rotX; updateOutfitLabel(); }

// Main event wiring
$$('[data-page]').forEach(el=>el.addEventListener('click',()=>goPage(el.dataset.page)));
$('#bottomColor').addEventListener('change',()=>{currentBottom=$('#bottomColor').value;updateAvatar();});
$('#kurtaStyle').addEventListener('change',()=>{currentStyle=$('#kurtaStyle').value;updateAvatar();});
$('#saveCurrent').addEventListener('click',saveCurrentLook);
$('#applyMeasurements').addEventListener('click',saveProfile);
$('#facePhoto').addEventListener('change',async e=>{const file=e.target.files?.[0];if(!file)return;if(file.size>10*1024*1024){toast('Please choose a photo under 10 MB.');e.target.value='';return;}try{const image=await compressImage(file,1000,.78);if(write(STORE.face,image)){showFace(image);toast('Face reference saved privately on this device.');}}catch{toast('Could not read that photo. Please try another one.');}});
$('#removeFace').addEventListener('click',()=>{showFace('');$('#facePhoto').value='';toast('Face reference removed from this app.');});
$('#productUpload').addEventListener('change',e=>saveProductFromUpload(e.target.files?.[0]));
$('#cancelProduct').addEventListener('click',()=>$('#productForm').classList.add('hidden'));
$('#saveProduct').addEventListener('click',commitProduct);
$('#lookSearch').addEventListener('input',renderCatalog);$('#vibeFilter').addEventListener('change',renderCatalog);
$$('[data-saved-tab]').forEach(b=>b.addEventListener('click',()=>setSavedTab(b.dataset.savedTab)));
$('#settingsOpen').addEventListener('click',()=>showSettings());$('#privacyOpen').addEventListener('click',()=>showPrivacy());$('#modalClose').addEventListener('click',closeModal);$('#modalBackdrop').addEventListener('click',e=>{if(e.target===$('#modalBackdrop'))closeModal();});
$$('[data-skin]').forEach(b=>{b.classList.toggle('chosen',b.dataset.skin===profile.skin);b.addEventListener('click',()=>{profile.skin=b.dataset.skin;$$('[data-skin]').forEach(x=>x.classList.toggle('chosen',x===b));write(STORE.profile,profile);updateAvatar();toast('Skin tone reference updated.');});});

document.addEventListener('click',e=>{
 const use=e.target.closest('[data-use-look]'); if(use){const id=use.dataset.useLook;const l=starterLooks.find(x=>(x.id||x.name)===id)||looks.find(x=>(x.id||x.name)===id);if(l)applyLook(l);return;}
 const save=e.target.closest('[data-save-look]'); if(save){const id=save.dataset.saveLook;const l=starterLooks.find(x=>(x.id||x.name)===id)||looks.find(x=>(x.id||x.name)===id);if(l){const exists=looks.some(x=>x.color===l.color&&x.bottom===l.bottom&&x.style===l.style);if(exists)toast('Already in your saved looks.');else{looks.unshift({...l,id:`look-${Date.now()}`});write(STORE.looks,looks);renderSaved();toast('Look saved.');}}return;}
 const saved=e.target.closest('[data-use-saved]');if(saved){const l=looks[Number(saved.dataset.useSaved)];if(l)applyLook(l);return;}
 const delLook=e.target.closest('[data-delete-look]');if(delLook){looks.splice(Number(delLook.dataset.deleteLook),1);write(STORE.looks,looks);renderSaved();toast('Saved look removed.');return;}
 const delProduct=e.target.closest('[data-delete-product]');if(delProduct){products.splice(Number(delProduct.dataset.deleteProduct),1);write(STORE.products,products);renderSaved();toast('Product removed.');return;}
 const prev=e.target.closest('[data-product-preview]');if(prev){const p=products[Number(prev.dataset.productPreview)];if(p){if(p.image){openModal('Product photo preview',`<div class="modal-product-preview"><img src="${p.image}" alt="${escapeHtml(p.name)}"></div><p class="muted">This shows the product image only. The current 3D preview cannot automatically map the exact photographed garment onto your model.</p><button class="primary full" id="previewProductPalette">Try a matching palette</button>`);$('#previewProductPalette').addEventListener('click',()=>{currentColor='#17483e';closeModal();applyLook({name:'Emerald Royal',color:currentColor,bottom:'#e8ddca',style:'classic'});});}else toast('No product image is saved for this item.');}return;}
});
function showSettings(){openModal('Settings & free use',`<div class="settings-list"><div class="setting-row"><div><strong>Local-first mode</strong><p>Avatar, measurements, product screenshots and saved looks stay in this browser/app storage.</p></div><span class="status-chip">ON</span></div><div class="setting-row"><div><strong>External AI services</strong><p>Not connected. This app makes no AI API calls and cannot spend money.</p></div><span class="status-chip">OFF</span></div><div class="setting-row"><div><strong>Daily unlimited use</strong><p>The 3D viewer, profile and saved looks have no model quota. Future photo-to-3D or neural try-on features may need local compute or eligible free-tier quotas.</p></div><span class="status-chip">LOCAL</span></div><button class="secondary full" id="exportData">Export profile & saved looks (JSON)</button><button class="danger-button full" id="clearData">Delete all local app data</button></div>`);$('#exportData').addEventListener('click',exportData);$('#clearData').addEventListener('click',()=>{openModal('Delete all local data?',`<p class="muted">This removes your saved profile, face reference, product screenshots and saved looks from this browser/app. This cannot be undone.</p><div class="form-actions"><button class="secondary" id="keepData">Cancel</button><button class="danger-button" id="confirmClear">Delete everything</button></div>`);$('#keepData').addEventListener('click',showSettings);$('#confirmClear').addEventListener('click',()=>{Object.values(STORE).forEach(k=>localStorage.removeItem(k));location.reload();});});}
function showPrivacy(){openModal('Privacy & current limits',`<div class="privacy-content"><h3>What stays on your device</h3><p>Your measurements, face reference, uploaded product images and saved outfits are stored in browser/app local storage. They are not uploaded by this prototype. Do not use a shared device if you do not want others using it to see your data.</p><h3>What this version can do</h3><ul><li>Render a consistent procedural 3D mannequin and reshape it using entered measurements.</li><li>Change kurta and pyjama colours and rotate the model.</li><li>Save outfit ideas and product screenshots privately.</li><li>Open live shopping searches in external stores.</li></ul><h3>What it cannot do yet</h3><ul><li>Reconstruct your exact face/body from photos.</li><li>Extract real 3D garment geometry from a product screenshot.</li><li>Predict real fit or size with certainty.</li><li>Search product inventories inside stores or verify live prices.</li></ul><p><strong>Accuracy matters:</strong> use product size charts and measurements before buying. A visual preview is not a fit guarantee.</p></div>`);}
function exportData(){const blob=new Blob([JSON.stringify({profile,looks,products:products.map(({image,...p})=>({...p,image:image?'[image omitted from lightweight export]':''})),exportedAt:new Date().toISOString()},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='fashion-twin-data.json';a.click();URL.revokeObjectURL(url);toast('Profile and saved looks exported. Product images are omitted.');}

// Boot
renderSwatches();renderHomeLooks();renderCatalog();renderSaved();fillProfileForm();showFace(faceData);updateProfileSummary();updateOutfitLabel();
try { init3D(); } catch(err) { console.error(err); $('#stage').innerHTML='<div class="loading-note">3D preview could not start. Open this app in a modern browser with WebGL enabled.</div>'; }
