# Fashion Twin — Local-first mobile prototype (v0.2)

A responsive mobile-first fashion fitting room built with Vite, Three.js and Capacitor. It is designed around the shopping needs of people who want clothes that flatter their own proportions without relying on generic model photos.

## What works in this version

- Responsive app UI with Studio, Discover, My Twin and Saved sections.
- Persistent procedural 3D mannequin that can be rotated and zoomed.
- Body profile inputs: height, weight, chest, waist, hips, shoulders, usual size and fit preference.
- Adjustable mannequin skin-tone reference.
- Outfit palette, bottom-wear colour and style previews (classic, minimal, layered).
- Curated style ideas, filtering and live search links to Indian shopping sites.
- Upload and locally save a clothing product screenshot, shop URL, size and price notes.
- Save/remove outfit looks and product shortlist items.
- Local export of profile and saved looks; delete-all local data control.
- No AI API calls, no backend, no subscription and no per-use cost for the implemented features.

## Honest limits

This is a functional prototype, not a finished photorealistic digital twin. The avatar is a procedural 3D mannequin driven by entered measurements; it does **not** reconstruct the user's exact face or body from photographs. The uploaded face photo is stored locally as a reference only. Product photos are saved to a private local shortlist; they are not automatically wrapped onto the 3D body. Outfit colour changes are illustrative previews, not real garment simulation or a size/fit guarantee. Shopping buttons open live search pages, not verified individual product listings.

A true Level 2 digital twin requires a suitable 3D human reconstruction/face-texture pipeline and calibration. Before integrating an open-source body model, verify the license for the exact model weights and intended use. A product screenshot alone does not contain enough information for exact 3D garment geometry.

## Run locally

Requirements: Node.js 20+ and a modern browser with WebGL.

```bash
npm install
npm run dev
```

Open the local Vite URL shown in the terminal. The UI uses Google Fonts if network access is available; system fonts are fallbacks.

## Build for Android

Install Android Studio and Android SDK first.

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

In Android Studio, allow Gradle sync and run on a device/emulator. To create an APK, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. For a distributable signed APK, use **Build > Generate Signed Bundle / APK**.

`android/` is not included yet; the commands above generate the native wrapper on the developer's machine.

## Data & privacy

Profile data, face-reference image, product screenshots and saved looks use browser/app local storage. They are not uploaded by this prototype. Local storage may be cleared by the OS/browser and has finite capacity. Product images are limited to 2 MB and face reference images to 3 MB. Use the app's delete-all control before handing the device to someone else.

## Zero-cost approach

The existing features use local JavaScript and Three.js. No hosted model or AI API is called, so these features have no AI quota or API bill. This is different from claiming that photorealistic photo-to-3D reconstruction or neural virtual try-on can run at unlimited quality on every phone. Those future features must use compatible local models or explicitly opt-in free-tier providers with hard no-billing safeguards.
